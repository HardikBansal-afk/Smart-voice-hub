from bluetooth_module import send_bluetooth_command

def control_device(command):
    if "light on" in command:
        print("💡 Turning ON the light")
        send_bluetooth_command("COM4", "light_on\n")
    elif "light off" in command:
        print("🔌 Turning OFF the light")
        send_bluetooth_command("COM4", "light_off\n")
    elif "fan on" in command:
        print("🌀 Turning ON the fan")
        send_bluetooth_command("COM4", "fan_on\n")
    elif "fan off" in command:
        print("🛑 Turning OFF the fan")
        send_bluetooth_command("COM4", "fan_off\n")
    else:
        print("❓ Command not recognized")
