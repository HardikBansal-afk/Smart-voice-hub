import speech_recognition as sr

def get_voice_command():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎤 Listening...")
        audio = recognizer.listen(source)
    try:
        command = recognizer.recognize_google(audio).lower()
        print(f"✅ You said: {command}")
        return command
    except sr.UnknownValueError:
        print("❌ Could not understand")
        return ""
