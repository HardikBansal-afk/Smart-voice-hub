from voice_command import get_voice_command
from device_controller import control_device

if __name__ == "__main__":
    while True:
        command = get_voice_command()
        if command:
            control_device(command)
