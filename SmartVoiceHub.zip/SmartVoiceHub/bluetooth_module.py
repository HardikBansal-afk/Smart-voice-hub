import serial
import time

def send_bluetooth_command(port, command):
    try:
        bt = serial.Serial(port, 9600, timeout=2)
        time.sleep(2)
        bt.write(command.encode())
        print(f"📡 Sent: {command}")
        bt.close()
    except Exception as e:
        print(f"❌ Error: {e}")
